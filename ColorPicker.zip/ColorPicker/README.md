Color Picker - instrukcja obsługi

====Opis====
Color Picker to narzędzie, które umożliwia wybór koloru.

====Funkcje====
1. Wybieranie kolorów.
2. Zapisywanie wybranych kolorów.

====Uruchamianie====
Aby uruchomić program, należy otworzyć plik ColorPicker.exe, który znajduje się w ścieżce "dist/ColorPicker/".

dist/ColorPicker/ColorPicker.exe

====Wybieranie koloru====
Aby wybrać kolor, należy ustawić suwaki RGB. Wybrany kolor zostanie wyświetlony na podglądzie i automatycznie zostaną wyświetlone kody koloru gotowe do skopiowania.

====Kopiowanie wybranego koloru====
Aby skopiować wybrany kolor, należy zaznaczyć wartość. Następnie skopiować wartość za pomocą ctrl + C.

Dziękujemy za skorzystanie z naszego narzędzia!