import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QPushButton, QWidget
from PyQt5.QtGui import QIcon

class Menu(QMainWindow):

    def __init__(self):
        super().__init__()

        # Tworzenie przycisków i przypisanie akcji
        button1 = QPushButton("Check your PC", self)
        button1.clicked.connect(self.play_game1)
        button2 = QPushButton("Ships", self)
        button2.clicked.connect(self.play_game2)
        button3 = QPushButton("Test your reflex!", self)
        button3.clicked.connect(self.play_game3)

        # Tworzenie menu poziomego
        hbox = QVBoxLayout()
        hbox.addWidget(button1)
        hbox.addWidget(button2)
        hbox.addWidget(button3)
        hbox.addStretch()

        # Ustawienie menu poziomego jako głównego widżetu okna
        central_widget = QWidget()
        central_widget.setLayout(hbox)
        self.setCentralWidget(central_widget)

        # Ustawienie tytułu i rozmiaru okna
        self.setWindowTitle('Menu z grami')
        self.setGeometry(350, 350, 350, 100)

        self.setWindowIcon(QIcon('game.png'))

    def play_game1(self):
        # Przekierowanie do pliku z kodem gry 1
        import os
        path = os.path.abspath(os.path.dirname(__file__))
        game1_path = os.path.join(path, 'pc.py')
        os.system(f'python {game1_path}')

    def play_game2(self):
        # Przekierowanie do pliku z kodem gry 2
        import os
        path = os.path.abspath(os.path.dirname(__file__))
        game2_path = os.path.join(path, 'ships.py')
        os.system(f'python {game2_path}')

    def play_game3(self):
        # Przekierowanie do pliku z kodem gry 3
        import os
        path = os.path.abspath(os.path.dirname(__file__))
        game3_path = os.path.join(path, 'reflex.py')
        os.system(f'python {game3_path}')


if __name__ == '__main__':
    app = QApplication(sys.argv)
    menu = Menu()
    menu.show()
    sys.exit(app.exec_())
