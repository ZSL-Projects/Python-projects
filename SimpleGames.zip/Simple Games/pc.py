import psutil
from PyQt5.QtCore import QTimer
from PyQt5.QtWidgets import QApplication, QMainWindow, QListWidget, QListWidgetItem
from PyQt5.QtGui import QIcon


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.initUI()

        # Start the timer to update the component information every 2 seconds
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.updateComponents)
        self.timer.start(2000)

        self.setWindowIcon(QIcon('game.png'))

    def initUI(self):
        self.setWindowTitle('PC components')
        self.setGeometry(100, 100, 400, 300)

        # Create QListWidget to display components
        self.componentList = QListWidget(self)
        self.componentList.setGeometry(10, 10, 380, 280)

        # Get and display CPU information
        cpu_percent = psutil.cpu_percent()
        cpu_item = QListWidgetItem(f'CPU usage: {cpu_percent}%')
        self.componentList.addItem(cpu_item)

        cpu_freq = psutil.cpu_freq()
        cpu_freq_item = QListWidgetItem(f'CPU frequency: {cpu_freq.current:.2f} MHz')
        self.componentList.addItem(cpu_freq_item)

        # Get and display memory information
        mem_info = psutil.virtual_memory()
        mem_total_item = QListWidgetItem(f'Memory total: {mem_info.total / 1024 / 1024:.2f} MB')
        self.componentList.addItem(mem_total_item)

        mem_used_item = QListWidgetItem(f'Memory used: {mem_info.used / 1024 / 1024:.2f} MB')
        self.componentList.addItem(mem_used_item)

        # Get and display disk information
        disk_usage = psutil.disk_usage('/')
        disk_total_item = QListWidgetItem(f'Disk total: {disk_usage.total / 1024 / 1024:.2f} MB')
        self.componentList.addItem(disk_total_item)

        disk_used_item = QListWidgetItem(f'Disk used: {disk_usage.used / 1024 / 1024:.2f} MB')
        self.componentList.addItem(disk_used_item)

        # Show the window
        self.show()

    def updateComponents(self):
        # Update CPU information
        cpu_percent = psutil.cpu_percent()
        self.componentList.item(0).setText(f'CPU usage: {cpu_percent}%')

        cpu_freq = psutil.cpu_freq()
        self.componentList.item(1).setText(f'CPU frequency: {cpu_freq.current:.2f} MHz')

        # Update memory information
        mem_info = psutil.virtual_memory()
        self.componentList.item(2).setText(f'Memory total: {mem_info.total / 1024 / 1024:.2f} MB')
        self.componentList.item(3).setText(f'Memory used: {mem_info.used / 1024 / 1024:.2f} MB')

        # Update disk information
        disk_usage = psutil.disk_usage('/')
        self.componentList.item(4).setText(f'Disk total: {disk_usage.total / 1024 / 1024:.2f} MB')
        self.componentList.item(5).setText(f'Disk used: {disk_usage.used / 1024 / 1024:.2f} MB')


if __name__ == '__main__':
    app = QApplication([])
    window = MainWindow()
    app.exec_()
