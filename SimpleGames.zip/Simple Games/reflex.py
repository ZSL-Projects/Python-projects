from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QVBoxLayout, QMessageBox
from PyQt5.QtGui import QColor
from PyQt5.QtCore import QTimer, QTime
from PyQt5.QtGui import QIcon
import random


class ReactionTime(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Gra w czas reakcji')
        self.setGeometry(100, 100, 300, 300)

        self.square = QPushButton(self)
        self.square.setGeometry(100, 100, 100, 100)
        self.square.setStyleSheet('background-color: grey')

        self.start_button = QPushButton('Start', self)
        self.start_button.setGeometry(100, 220, 100, 40)
        self.start_button.clicked.connect(self.start_game)

        layout = QVBoxLayout()
        layout.addWidget(self.square)
        layout.addWidget(self.start_button)
        self.setLayout(layout)

        self.game_timer = QTimer()
        self.game_timer.setSingleShot(True)
        self.game_timer.timeout.connect(self.reaction)

        self.setWindowIcon(QIcon('game.png'))

    def start_game(self):
        self.square.setStyleSheet('background-color: grey')
        self.start_button.setDisabled(True)
        min_time = 1000
        max_time = 10000
        random_time = random.randint(min_time, max_time)
        self.game_timer.start(random_time)

        self.square.clicked.connect(self.false_start)

    def false_start(self):
        self.game_timer.stop()
        self.square.setStyleSheet('background-color: grey')
        self.square.clicked.disconnect()
        self.start_button.setEnabled(True)
        self.show_alert('Falstart')

    def reaction(self):
        self.square.setStyleSheet('background-color: red')
        self.square.clicked.disconnect()
        self.square.clicked.connect(self.end_game)

        self.start_time = QTime.currentTime()

    def end_game(self):
        self.square.setStyleSheet('background-color: grey')
        self.square.clicked.disconnect()
        self.start_button.setEnabled(True)

        end_time = QTime.currentTime()
        reaction_time = self.start_time.msecsTo(end_time)

        self.show_alert(f'Twój czas wynosi: {reaction_time} ms')

    def show_alert(self, message):
        alert = QMessageBox()
        alert.setText(message)
        alert.exec_()


if __name__ == '__main__':
    app = QApplication([])
    window = ReactionTime()
    window.show()
    app.exec_()
