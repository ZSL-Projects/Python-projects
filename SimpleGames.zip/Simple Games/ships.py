import sys
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *
import random

class Battleship(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
        self.initGame()

    def initUI(self):
        self.setWindowTitle('Battleship')
        self.setGeometry(100, 100, 500, 500)

        self.grid = QGridLayout()
        self.grid.setSpacing(0)
        self.grid.setColumnMinimumWidth(0, 50)
        self.grid.setColumnMinimumWidth(11, 50)
        self.grid.setRowMinimumHeight(0, 50)
        self.grid.setRowMinimumHeight(11, 50)

        for i in range(1, 11):
            for j in range(1, 11):
                button = QPushButton()
                button.setFixedSize(40, 40)
                button.clicked.connect(self.buttonClicked)
                self.grid.addWidget(button, i, j)

        self.setLayout(self.grid)

        self.show()

        self.setWindowIcon(QIcon('game.png'))

    def initGame(self):
        self.gameOver = False
        self.shipCoords = []
        self.hits = 0
        self.misses = 0

        for i in range(10):
            row = random.randint(1, 10)
            col = random.randint(1, 10)
            if (row, col) not in self.shipCoords:
                self.shipCoords.append((row, col))

    def buttonClicked(self):
        if not self.gameOver:
            button = self.sender()
            row = self.grid.getItemPosition(self.grid.indexOf(button))[0]
            col = self.grid.getItemPosition(self.grid.indexOf(button))[1]
            coords = (row, col)
            if coords in self.shipCoords:
                button.setText("O")
                self.hits += 1
                self.checkGameOver()
            else:
                button.setText("X")
                self.misses += 1
                self.checkGameOver()

    def checkGameOver(self):
        if self.hits == len(self.shipCoords):
            self.gameOver = True
            QMessageBox.information(self, "Wygrana!", "Gratulacje! Udało Ci się zatopić wszystkie statki!.")
            self.close()
            self.__init__()
        elif self.misses >= 40:
            self.gameOver = True
            QMessageBox.information(self, "Przegrana!", "Nie zatopiłeś wszystkich statków!")
            self.close()
            self.__init__()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    battleship = Battleship()
    sys.exit(app.exec_())
