import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QPushButton, QLabel, QGridLayout, QWidget

class Gra(QMainWindow):
    def __init__(self):
        super().__init__()

        self.board = [' '] * 9
        self.turn = 'X'
        self.winner = None

        self.initUI()

    def initUI(self):
        self.setGeometry(100, 100, 300, 300)
        self.setWindowTitle('Kółko i krzyżyk')

        self.message_label = QLabel('Tura gracza ' + self.turn, self)
        self.message_label.setGeometry(10, 10, 200, 30)

        self.grid = QGridLayout()
        self.grid.setSpacing(10)

        for i in range(3):
            for j in range(3):
                button = QPushButton('', self)
                button.clicked.connect(self.buttonClicked)
                button.setProperty('row', i)
                button.setProperty('col', j)
                self.grid.addWidget(button, i, j)

        widget = QWidget(self)
        widget.setLayout(self.grid)
        self.setCentralWidget(widget)

        self.show()

    def buttonClicked(self):
        button = self.sender()
        row = button.property('row')
        col = button.property('col')

        index = row * 3 + col
        if self.board[index] == ' ' and not self.winner:
            self.board[index] = self.turn
            button.setText(self.turn)

            if self.checkWinner():
                self.winner = self.turn
                self.message_label.setText('Gracz ' + self.turn + ' wygrywa!')
            elif ' ' not in self.board:
                self.winner = 'Remis'
                self.message_label.setText('Remis')
            else:
                self.turn = 'O' if self.turn == 'X' else 'X'
                self.message_label.setText('Tura gracza ' + self.turn)

    def checkWinner(self):
        for i in range(3):
            if self.board[i*3] == self.board[i*3+1] == self.board[i*3+2] != ' ':
                return True
            if self.board[i] == self.board[i+3] == self.board[i+6] != ' ':
                return True
        if self.board[0] == self.board[4] == self.board[8] != ' ':
            return True
        if self.board[2] == self.board[4] == self.board[6] != ' ':
            return True
        return False

if __name__ == '__main__':
    app = QApplication(sys.argv)
    game = Gra()
    sys.exit(app.exec_())
